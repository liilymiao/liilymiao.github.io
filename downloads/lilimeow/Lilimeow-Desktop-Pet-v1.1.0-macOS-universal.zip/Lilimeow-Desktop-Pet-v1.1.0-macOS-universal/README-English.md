# Lilimeow — standalone macOS desktop pet

Lilimeow is a self-contained macOS app with no Codex dependency. It plays on its phone by default and switches to typing on a laptop whenever the pointer hovers over it.

## Requirements

- macOS 13 Ventura or later.
- Apple Silicon or Intel Mac (Universal 2 build).
- No Codex account, login, network connection, or special permission is required.

## Install and launch

1. Unzip the archive.
2. Drag `Lilimeow.app` into the Applications folder.
3. On first launch, Control-click or right-click `Lilimeow.app`, choose **Open**, then confirm once more.

This build is ad-hoc signed and is not notarized with an Apple Developer ID. If macOS blocks it, first verify that the ZIP came from someone you trust, then use **System Settings → Privacy & Security → Open Anyway**.

## Controls

- Move: left-drag Lilimeow. The position is restored on the next launch.
- Hover easter egg: move the pointer over Lilimeow to make it type; move away to return to the phone.
- Manual modes: right-click Lilimeow and choose **Auto**, **Idle**, or **Working**.
- Size: right-click and choose Small `160 px`, Standard `192 px`, or Large `224 px`. Standard is the default.
- Reset position: right-click and choose **Reset Position**.
- Quit: right-click and choose **Quit Lilimeow**.

## Privacy and network behavior

Lilimeow has no network communication and reads no Codex or third-party app files. Hover detection is limited to Lilimeow's own transparent window and requires neither Input Monitoring nor Accessibility permission.

## Uninstall

Quit Lilimeow from its right-click menu, then delete `/Applications/Lilimeow.app`.
