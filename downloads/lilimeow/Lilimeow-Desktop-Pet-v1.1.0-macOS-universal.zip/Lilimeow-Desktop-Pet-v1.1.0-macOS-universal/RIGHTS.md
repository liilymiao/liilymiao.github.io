# Rights and attribution / 权利与归属说明

This package is intended for recipients to install and use the Lilimeow desktop pet. It does not include an open-source or commercial-use license. Redistribution, modification, resale, or commercial use requires permission from the package author.

本包用于接收者安装和使用粒粒喵桌宠，未附带开源或商业使用许可。如需再发布、修改、转售或商业使用，请先征得本包作者许可。

The simplified Apple silhouettes shown on the phone and laptop are referential decorative marks. Apple and the Apple logo are trademarks of Apple Inc. This project is not affiliated with, endorsed by, or sponsored by Apple Inc.

手机和笔记本电脑上的简化 Apple 轮廓仅作为指代性装饰元素。Apple 及 Apple 标志是 Apple Inc. 的商标。本项目与 Apple Inc. 无关，也未获得其认可或赞助。

Reference images used during the design process are not included in this release archive.

设计过程中使用的参考图不包含在本发布包中。
